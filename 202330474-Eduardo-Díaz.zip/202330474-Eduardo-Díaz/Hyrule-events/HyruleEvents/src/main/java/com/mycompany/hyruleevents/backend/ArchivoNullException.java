/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.hyruleevents.backend;

/**
 *
 * @author edu
 */
public class ArchivoNullException extends Exception {

    public ArchivoNullException() {
        super("El archivo de entrada es null");
    }


    
}
