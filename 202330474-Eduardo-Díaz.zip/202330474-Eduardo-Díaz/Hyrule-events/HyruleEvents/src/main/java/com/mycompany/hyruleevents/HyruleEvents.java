/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.hyruleevents;

import com.mycompany.hyruleevents.fronted.HyruleInterfaz;

/**
 *
 * @author edu
 */
public class HyruleEvents {

    public static void main(String[] args) {
        HyruleInterfaz ventanaPrincipal = new HyruleInterfaz();
        ventanaPrincipal.setVisible(true);
    }
}
